/data/plugin/XcamIraq
/data/iap/run.sh &
