#### "*******************************************"
#### "*          << RAED - fairbird >>          *"
#### "*******************************************"
#### "****************************************************************"             
#### "*Read more: https://www.tunisia-sat.com/forums/threads/3539021/*"
#### "****************************************************************"
##################################
# To Enable Free Server delete #
##################################
#SERVER1
#SERVER4
#SERVER5
#SERVER11
#SERVER12
#SERVER15
########################################################
#SERVER0 ## more than 50 server in one server (Some Stable - ثابت نسبياًُ)
#SERVER18 ## more than 10 server in one server (Not Stable - غير ثابت)
#SERVER19 ## more than 100 server in one server (Not Stable - غير ثابت)


################# CCcam Lines ############
# C: yourhost.dyndns.org 12000 user pass

################# Newcamd Lines ############
# N: yourhost.dyndns.org 1234 user pass 01 02 03 04 05 06 07 08 09 10 11 12 13 14

############################################

############Free Server##################
# To Enable Free Server Delete #

https://cccam.net/free
https://cccamia.com/free-cccam/
https://cccamtiger.com/fcccam/
https://www.cccambird.com/freecccam.php
https://www.cccambird2.com/freecccam.php
https://cccamiptv.co/free-cccam/
https://cccamprime.com/cccam48h.php
https://cccam-premium.com/free-cccam/
https://skyhd.xyz/freetest/test1.php
https://cccamx.com/v2/getCode.php
http://www.premiumcccam.store/TEST24.php
http://cccamprima.com/free5/get2.php
https://cccamfrei.com/free/get.php
https://www.tvlivepro.com/free_cccam_48h/
