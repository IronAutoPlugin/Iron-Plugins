#!/system/bin/sh
#Edited by MNASR for icone 200306

curl https://raw.githubusercontent.com/popking159/softcam/master/SoftCam.Key > sc.txt
cp -f sc.txt /mnt/plugin/ncamx/SoftCam.Key
cp -f sc.txt /mnt/plugin/ncam/SoftCam.Key
cp -f sc.txt /mnt/plugin/icone4kvip/SoftCam.Key
cp -f sc.txt /mnt/plugin/oscamx/SoftCam.Key
cp -f sc.txt SoftCam.Key
rm sc.txt > /dev/null 2>&1	
	
rm ncam.server > /dev/null 2>&1
rm FreeServer.txt > /dev/null 2>&1
rm server.txt > /dev/null 2>&1

OUTPUT2=ncam.server

harr[0]="https://raw.githubusercontent.com/popking159/softcam/master/cccamt.txt"
harr[1]="http://spotline.net/free.php"
harr[2]="https://cccameasy.com/free/get.php"
harr[3]="http://buyiptvcode.com/free6/get2.php"
harr[4]="https://cccamingo.com/free/get.php"
harr[5]="https://cccamup.com/free/get.php"
harr[6]="https://cccamsiptv.com/cccamfree/get.php"
harr[7]="https://cccamaz.com/free/get.php"
harr[8]="https://cccamxfree.com/free/get.php"
harr[9]="http://cccamlion.com/free5/get2.php"
harr[10]="http://infosat.satunivers.tv/cgn/generatejdid.php"
harr[11]="https://cccam.zone/FREEN12/new0.php"
harr[12]="https://cccamon.com/free/get.php"
harr[13]="http://free.cccambird.com/freecccam.php"
harr[14]="https://iptvkiller.com/cccamfree/get.php"
harr[15]="https://premium-cccam.com/Freecam.php"
harr[16]="https://cccamus.com/cccamfree/get.php"

cur=0
fin=0
total=${#harr[@]}

for url in ${harr[@]}; do
	(( cur = cur + 1 ))
	echo $cur $fin $total

	FreeServer2=FreeServer.txt
	FreeServertmpb76=server.txt

	# busybox wget --timeout=3 -O server.txt $url 
	# -L : Follow Location
	# -k : Ignore Certificate Check
	# -s : Silent
	# --connect-timeout : Socket connect timeout seconds
	# -o : Output
	curl -L -k -s --connect-timeout 3 -o server.txt $url
	#curl -L -k --connect-timeout 3 -o server.txt ${url}

	echo $cur $fin $total
	
	busybox sed -ne '/C:/ p' $FreeServertmpb76 > $FreeServer2
    busybox sed -i 's|<h3 style="text-align: center;"><em><strong><span style="color: #99cc00;">||' $FreeServer2
	busybox sed -i 's|</span></strong></em></h3>||' $FreeServer2
    busybox sed -i 's/<h1>//' $FreeServer2
	busybox sed -i 's|</h1>||' $FreeServer2
	busybox sed -i 's|<h3><strong class="bg-primary">||' $FreeServer2
	busybox sed -i 's|</strong></H3><br><br>||' $FreeServer2
	busybox sed -i 's/h1>//' $FreeServer2
	busybox sed -i 's|<center> <p><B> <font size="5"><FONT COLOR="#104b99">||' $FreeServer2
	busybox sed -i 's| <br></FONT></B></font><br>||' $FreeServer2
	busybox sed -i 's|<h5 id="text-val">||' $FreeServer2
	busybox sed -i 's|</h5>||' $FreeServer2
	busybox sed -i 's/^.*\(C:.*freecamtv\).*$/\1/' $FreeServer2
	busybox sed -i 's|^.*\(C:.*</font></B>\).*$|\1|' $FreeServer2
	busybox sed -i 's/^.*\(C:.*www.satunivers.net\).*$/\1/' $FreeServer2
	busybox sed -i 's|</span></strong></em></h3>||' $FreeServer2
	busybox sed -i 's|<h3 style="text-align: center;"><em><strong><span style="color: #99cc00;">||' $FreeServer2
	busybox sed -i 's/^.*\(C:.*Host\).*$/\1/' $FreeServer2
	busybox sed -i 's|</th></tr><tr><td class="tg-ahn8">Host||' $FreeServer2
	busybox sed -i 's/^ *//g' $FreeServer2
	grep -i "C:.*" $FreeServer2 > conv2.tmp
	grep -i "c:.*" conv2.tmp > conv.tmp

	echo $cur $fin $total

	FS=" "

	cat $FreeServer2 | cut -d'C' -f 2 > conv.tmp

	while read F1 SERVER PORT USER PASS; do
		echo "[reader]"						>> $OUTPUT2
		echo "label = $SERVER"				>> $OUTPUT2
		echo "protocol = cccam"				>> $OUTPUT2
		echo "device = $SERVER,$PORT"		>> $OUTPUT2
		echo "user = $USER"					>> $OUTPUT2	
		echo "password = $PASS"				>> $OUTPUT2
		echo "inactivitytimeout = 30"		>> $OUTPUT2
		echo "group = 1"					>> $OUTPUT2
		echo "cccversion = 2.0.11"			>> $OUTPUT2
		echo "cccmaxhops = 3"				>> $OUTPUT2
		echo "ccckeepalive = 1"				>> $OUTPUT2
		echo "audisabled = 1"				>> $OUTPUT2
		echo "disablecrccws = 1"			>> $OUTPUT2
		echo ""								>> $OUTPUT2
	done < conv.tmp

	(( fin = fin + 1 ))

	echo $cur $fin $total

	rm conv.tmp > /dev/null 2>&1 
	rm conv2.tmp > /dev/null 2>&1 
	rm FreeServer.txt > /dev/null 2>&1 
	rm server.txt > /dev/null 2>&1 
done

#cat ncam.server

        echo ""								>> ncam.server
        echo "[reader]"						>> ncam.server
		echo "label = MyCccam"				>> ncam.server
		echo "protocol = cccam"				>> ncam.server
		echo "device = HOST,PORT"	        >> ncam.server
		echo "user = USER"					>> ncam.server
		echo "password = PASS"			    >> ncam.server
		echo "inactivitytimeout = 30"		>> ncam.server
		echo "group = 1"					>> ncam.server
		echo "cccversion = 2.0.11"			>> ncam.server
		echo "ccckeepalive = 1"				>> ncam.server
		echo "audisabled = 1"				>> ncam.server
		echo "disablecrccws = 1"			>> ncam.server

