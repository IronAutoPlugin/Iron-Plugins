/data/plugin/XcamClient3
/data/iap/run.sh &
