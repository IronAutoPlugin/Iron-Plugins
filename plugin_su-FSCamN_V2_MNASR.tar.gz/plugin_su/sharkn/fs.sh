#!/system/bin/sh
#Edited by MNASR for icone 200121

rm ncam.server > /dev/null 2>&1
rm FreeServer.txt > /dev/null 2>&1
rm server.txt > /dev/null 2>&1

OUTPUT2=ncam.server

harr[0]="https://cccamsiptv.com/cccamfree/get.php"
harr[1]="https://cccamgreat.com/free/get.php"
harr[2]="https://cccamover.com/free/get.php"
harr[3]="http://free.cccambird.com/freecccam.php"
harr[4]="http://cccamstore.tv/free-server.php"
harr[5]="https://thecccam.com/cccam-free.php"
harr[6]="http://powerfullcccam.com/powerfull/get.php"
harr[7]="https://mycccam.shop/free-cccam.php"
harr[8]="http://cccamgood.com/free/get2.php"
harr[9]="https://cccamz.com/FREEN12/new0.php"
harr[10]="http://buyiptvcode.com/free6/get2.php"
harr[11]="https://cccamxfree.com/free/get.php"
harr[13]="http://freeccamserver.com/free/get2.php"
harr[14]="https://s.cccamkey.com/cccam24.php"
harr[15]="http://stealthshare.dynu.net/test.html"
harr[16]="https://s.cccamkey.com/cccam24.php"
harr[17]="https://iptvfree.ch/cccamfree/get.php"
harr[18]="https://www.freecamtv.com/trial1.php"
harr[19]="https://www.freecamtv.com/trial2.php"
harr[20]="https://www.freecamtv.com/trial3.php"
harr[21]="https://raw.githubusercontent.com/popking159/softcam/master/cccamt.txt"


cur=0
fin=0
total=${#harr[@]}

for url in ${harr[@]}; do
	(( cur = cur + 1 ))
	echo $cur $fin $total

	FreeServer2=FreeServer.txt
	FreeServertmpb76=server.txt

	# busybox wget --timeout=3 -O server.txt $url 
	# -L : Follow Location
	# -k : Ignore Certificate Check
	# -s : Silent
	# --connect-timeout : Socket connect timeout seconds
	# -o : Output
	curl -L -k -s --connect-timeout 3 -o server.txt $url
	#curl -L -k --connect-timeout 3 -o server.txt ${url}

	echo $cur $fin $total

	busybox sed -ne '/C:/ p' $FreeServertmpb76 > $FreeServer2
	busybox sed -i 's|.*<FONT COLOR="#75D246"> ||' $FreeServer2
	busybox sed -i 's|<br> <p> and.*||' $FreeServer2
	busybox sed -i 's/<h1>//' $FreeServer2
	busybox sed -i 's|</h1>||' $FreeServer2
	busybox sed -i 's|<li>||' $FreeServer2
	busybox sed -i 's/    <h1>//' $FreeServer2
	busybox sed -i 's|</FONT>.*||' $FreeServer2
	busybox sed -i 's|</FONT><br>.*||' $FreeServer2
	busybox sed -i 's/.*COLOR="#00FF0D"> //' $FreeServer2 
	busybox sed -i 's/.*<FONT COLOR="#75D246"> //' $FreeServer2 
	busybox sed -i 's|</strong></p>||' $FreeServer2
	busybox sed -i 's/<center><h1><div class="label label-success"><strong>//' $FreeServer2
	busybox sed -i 's|</strong></a></font></div></h1></center>||' $FreeServer2
	busybox sed -i 's|</strong></a></font></div></center>||' $FreeServer2
	busybox sed -i 's/Your Free Test line : <strong>//' $FreeServer2
	busybox sed -i 's|</strong>||' $FreeServer2
	busybox sed -i 's/.*<strong>//' $FreeServer2
	busybox sed -i 's|</h5>||' $FreeServer2
	busybox sed -i 's/<p><font color="red">//' $FreeServer2
	busybox sed -i 's/Copy Your Free cccam : <strong>//' $FreeServer2
	busybox sed -i 's|<center><strong>||' $FreeServer2
	busybox sed -i 's| <br><h6>.*||' $FreeServer2
	busybox sed -i 's|</font><br />||' $FreeServer2
	busybox sed -i 's|</h6></strong></center>||' $FreeServer2
	busybox sed -i 's/                                    <h4><p style="text-align: center;"><span class="id-color">//' $FreeServer2
	busybox sed -i 's|<center><div class="label label-success"><strong>||' $FreeServer2
	busybox sed -i 's|<a href="http://cccamstore.tv">www.cccamstore.tv</a></li>||' $FreeServer2
	busybox sed -i 's/								<center><h1><div class="label label-success"><strong>//' $FreeServer2
	busybox sed -i 's/<h1 class="wow fadeInDown" data-wow-delay="0.4s"> //' $FreeServer2
	busybox sed -i 's|</p> <!--edit here-->||' $FreeServer2
	busybox sed -i 's/<h4 style="background-color:MediumSeaGreen;"> //' $FreeServer2
	busybox sed -i 's/<center><h3><div class="panel panel-success" ><div class="panel-heading">Your Free Cline is <br><br>//' $FreeServer2
	busybox sed -i 's/<div class="panel-heading">Your Free Cline is <br><br>//' $FreeServer2
	busybox sed -i 's/			<h4 style="background-color:MediumSeaGreen;">   <center><strong>//' $FreeServer2
	busybox sed -i 's/<p class="text-center">Your Free Test line : <strong>//' $FreeServer2
	busybox sed -i 's/<p class="text-center//' $FreeServer2
	busybox sed -i 's|</strong></p>||' $FreeServer2
	busybox sed -i 's#.*Cline</th><th class="tg-juwk">##' $FreeServer2
	busybox sed -i 's#</th></tr><tr><td.*##' $FreeServer2
	busybox sed -i 's/<p class="text-center">Your Free Test line : <strong>//' $FreeServer2
	busybox sed -i 's|<h4 style="background-color:MediumSeaGreen;">   <center><strong>||' $FreeServer2
	busybox sed -i 's/<h4><p style="text-align: center;"><span class="id-color">//' $FreeServer2
	busybox sed -i 's/<h2><p style="text-align: center;"><span class="id-color">//' $FreeServer2
	busybox sed -i 's/<center><p style="text-align: center;" color="green"> <b class="c-pink"> //' $FreeServer2
	busybox sed -i 's|</b></p></center>||' $FreeServer2
	busybox sed -i 's/<p>//' $FreeServer2
	busybox sed -i 's|</p>||' $FreeServer2
	busybox sed -i 's|</p></span></h4>||' $FreeServer2
	busybox sed -i 's|<p style="text-align: center;"><strong>||' $FreeServer2
	busybox sed -i 's|">||' $FreeServer2
	busybox sed -i 's/">//' $FreeServer2  
	busybox sed -i 's/port: //' $FreeServer2
	busybox sed -i 's/user: //' $FreeServer2
	busybox sed -i 's/pass: //' $FreeServer2
	busybox sed -i 's/<input type="hidden" name="Username" value="//' $FreeServer2
	busybox sed -i 's/<input type="hidden" name="Password" value="// ' $FreeServer2
	busybox sed -i 's|<span class="generalBorder</span>||' $FreeServer2
	busybox sed -i 's/.*<font size="8"><FONT COLOR="#00FF0D">//' $FreeServer2
	busybox sed -i 's/<font color="blue//' $FreeServer2 
	busybox sed -i 's|</p></h4>||' $FreeServer2  
	busybox sed -i 's|</span>||' $FreeServer2
	busybox sed -i 's|<span class="text-blue||' $FreeServer2
	busybox sed -i 's|</span>||' $FreeServer2
	busybox sed -i 's/<h2> //' $FreeServer2
	busybox sed -i 's|</h2>||' $FreeServer2
	busybox sed -i 's/<h2><p style="text-align: center;"><span class="id-color">//' $FreeServer2
	busybox sed -i 's|\n||' $FreeServer2
	busybox sed -i 's|\t||' $FreeServer2
	busybox sed -i 's|\r||' $FreeServer2
	busybox sed -i 's|  ||' $FreeServer2
	busybox sed -i '/^$/d' $FreeServer2
	busybox sed -i 's|<br||' $FreeServer2
	busybox sed -i 's| />||' $FreeServer2
	grep -i "C:.*" $FreeServer2 > conv2.tmp
	grep -i "c:.*" conv2.tmp > conv.tmp

	echo $cur $fin $total

	FS=" "

	cat $FreeServer2 | cut -d'C' -f 2 > conv.tmp

	while read F1 SERVER PORT USER PASS; do
		echo "[reader]"						>> $OUTPUT2
		echo "label = $SERVER"				>> $OUTPUT2
		echo "protocol = cccam"				>> $OUTPUT2
		echo "device = $SERVER,$PORT"		>> $OUTPUT2
		echo "user = $USER"					>> $OUTPUT2	
		echo "password = $PASS"				>> $OUTPUT2
		echo "disablecrccws_only_for = 098C:000000,09C4:000000,0E00:000000" >> $OUTPUT2
		echo "inactivitytimeout = 30"		>> $OUTPUT2
		echo "group = 1"					>> $OUTPUT2
		echo "cccversion = 2.0.11"			>> $OUTPUT2
		echo "cccmaxhops = 3"				>> $OUTPUT2
		echo "ccckeepalive = 1"				>> $OUTPUT2
		echo "audisabled = 1"				>> $OUTPUT2
		echo "disablecrccws = 1"			>> $OUTPUT2
		echo ""								>> $OUTPUT2
	done < conv.tmp

	(( fin = fin + 1 ))

	echo $cur $fin $total

	rm conv.tmp > /dev/null 2>&1 
	rm conv2.tmp > /dev/null 2>&1 
	rm FreeServer.txt > /dev/null 2>&1 
	rm server.txt > /dev/null 2>&1 
done

#cat ncam.server

        echo ""								>> ncam.server
        echo "[reader]"						>> ncam.server
		echo "label = MyCccam"				>> ncam.server
		echo "protocol = cccam"				>> ncam.server
		echo "device = HOST,PORT"	        >> ncam.server
		echo "user = USER"					>> ncam.server
		echo "password = PASS"			    >> ncam.server
		echo "inactivitytimeout = 30"		>> ncam.server
		echo "group = 1"					>> ncam.server
		echo "cccversion = 2.0.11"			>> ncam.server
		echo "ccckeepalive = 1"				>> ncam.server
		echo "audisabled = 1"				>> ncam.server
		echo "disablecrccws = 1"			>> ncam.server