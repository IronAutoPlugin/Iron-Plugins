#!/system/bin/sh

rm oscam.server > /dev/null 2>&1
rm FreeServer.txt > /dev/null 2>&1
rm server.txt > /dev/null 2>&1
rm /mnt/plugin/ncam/ncam.server > /dev/null 2>&1
rm /mnt/plugin/ncamx/ncam.server > /dev/null 2>&1

OUTPUT2=oscam.server
OUTPUT3=/mnt/plugin/ncam/ncam.server
OUTPUT4=/mnt/plugin/ncamx/ncam.server
#HOST
harr[0]="http://ia601509.us.archive.org/5/items/dreamosat/CCCAM.txt"  
harr[1]="http://ia601509.us.archive.org/5/items/dreamosat/free-server1.txt"
harr[2]="http://ia601509.us.archive.org/5/items/dreamosat/free-server2.txt"
harr[3]="http://ia601509.us.archive.org/5/items/dreamosat/free-server3.txt"
harr[4]="http://ia601509.us.archive.org/5/items/dreamosat/free-server4.txt"
harr[5]="http://ia601509.us.archive.org/5/items/dreamosat/free-server5.txt"
harr[6]="http://ia601509.us.archive.org/5/items/dreamosat/free-server6.txt"
harr[7]="http://ia601509.us.archive.org/5/items/dreamosat/free-server7.txt"
harr[8]="http://ia601509.us.archive.org/5/items/dreamosat/free-server8.txt"
harr[9]="http://ia601509.us.archive.org/5/items/dreamosat/free-server9.txt"
harr[10]="http://ia601509.us.archive.org/5/items/dreamosat/free-server10.txt"
harr[11]="https://www.freecamtv.com/trial1.php"
harr[12]="https://cccamking.com/free/get.php"
harr[13]="https://thecccam.com/cccam-free.php"
harr[14]="http://bosscccam.co/Test.php"
harr[15]="https://cccamgate.net/24hcccam-test.php"
harr[16]="http://powerfullcccam.com/powerfull/get.php"
harr[17]="https://mycccam.shop/free-cccam.php"
harr[18]="http://cccamgood.com/free/get2.php"
harr[19]="https://cccamz.com/FREEN12/new0.php"
harr[20]="http://cccam.algsat.com/freez.html"
harr[21]="http://buyiptvcode.com/free6/get2.php"
harr[22]="https://cccamgate.vip/free-cccam.php"
harr[23]="https://www.mycccam24.com/tss1.php"
harr[24]="http://freeccamserver.com/free/get2.php"
harr[25]="https://www.freecamtv.com/tss1.php"
#harr[26]="https://www.topcamd.com/get1.php"
#harr[27]="https://www.topcamd.com/get2.php"
#harr[28]="https://www.bluecccam.com/cline1.php"
harr[29]="http://cccamstore.tv/free-server.php"
harr[30]="https://cccamz.com/FREEN12/new0.php"
harr[31]="https://cccamz.com/FREEN12/new0.php"
harr[32]="https://cccamz.com/FREEN12/new0.php"
harr[33]="https://cccamgz.com/FREEN12/new0.php"
harr[34]="http://cccammania.com/free4/get2.php"
harr[35]="http://cccamgenerador.com/gratis/get2.php"
harr[36]="http://stealthshare.dynu.net/test.html"
harr[37]="https://s.cccamkey.com/cccam24.php"
harr[38]="http://infosat.satunivers.tv/cgn/generatejdid.php"
harr[39]="https://iptvfree.ch/cccamfree/get.php"
#harr[40]="https://cccamover.com/free/get.php"
harr[41]="http://free.cccambird.com/freecccam.php"
harr[42]="https://cccamover.com/free/get.php"
harr[43]="https://vipcccam.net/free-cccam.php"
harr[44]="https://cccamgreat.com/free/get.php"
#harr[45]="http://ow.ly/8RwH30isH1g"
harr[46]="http://cccam24h.com/lik1.php"
harr[47]="https://cccam4all.net/13vjnlkjlkv.html"
harr[48]="http://eurohd.ddns.us/Tv/freetest.php"
harr[49]="https://www.cccamtiger.com/freecccam48h.php"
harr[50]="http://mycccam24.com/server2.php"
harr[51]="http://mycccam24.com/server3.php"
harr[52]="https://www.freecamtv.com/server2.php"
harr[53]="https://www.freecamtv.com/server3.php"
harr[54]="http://paycccam.com/homepage/cccam-server-test/cccam-test/"
harr[55]="http://www.cccamlive.com/tests/takeatest/"
harr[56]="https://www.iptvhd7.com/cccam-hd-free-2020/"
harr[57]="http://infosat.satunivers.tv/download1.php?file=srtx5.txt"
harr[58]="https://cccamus.com/index.html#free"
harr[59]="https://scccam.com/freecccam.php"
harr[60]="https://scccam.com/freecccam.php"
harr[61]="http://cccam-deutschland.com/cccamtest.php"
harr[62]="https://www.cccamlux.com/Free-CCcam.php"
harr[63]="http://www.powercccam.net/free-server.php"
harr[64]="https://scccam.com/freecccam.php"
harr[65]="https://cccamus.com/index.html#free"
harr[66]="https://cccamover.com/#about"

cur=0
fin=0
total=${#harr[@]}

for url in ${harr[@]}; do
	(( cur = cur + 1 ))
	echo $cur $fin $total

	FreeServer2=FreeServer.txt
	FreeServertmpb76=server.txt

	# busybox wget --timeout=3 -O server.txt $url
	# -L : Follow Location
	# -k : Ignore Certificate Check
	# -s : Silent
	# --connect-timeout : Socket connect timeout seconds
	# -o : Output
	curl -L -k -s --connect-timeout 3 -o server.txt $url
	#curl -L -k --connect-timeout 3 -o server.txt ${url}

	echo $cur $fin $total

#Clean  
	busybox sed -ne '/C:/ p' $FreeServertmpb76 > $FreeServer2
	busybox sed -i 's|.*<FONT COLOR="#75D246"> ||' $FreeServer2
	busybox sed -i 's|<br> <p> and.*||' $FreeServer2
	busybox sed -i 's/<h1>//' $FreeServer2
	busybox sed -i 's|</h1>||' $FreeServer2
	busybox sed -i 's|<li>||' $FreeServer2
	busybox sed -i 's/    <h1>//' $FreeServer2
	busybox sed -i 's|</FONT>.*||' $FreeServer2
	busybox sed -i 's|</FONT><br>.*||' $FreeServer2
	busybox sed -i 's/.*COLOR="#00FF0D"> //' $FreeServer2
	busybox sed -i 's/.*<FONT COLOR="#75D246"> //' $FreeServer2
	busybox sed -i 's|</strong></p>||' $FreeServer2
	busybox sed -i 's/<center><h1><div class="label label-success"><strong>//' $FreeServer2
	busybox sed -i 's|</strong></a></font></div></h1></center>||' $FreeServer2
	busybox sed -i 's|</strong></a></font></div></center>||' $FreeServer2
	busybox sed -i 's/Your Free Test line : <strong>//' $FreeServer2
	busybox sed -i 's|</strong>||' $FreeServer2
	busybox sed -i 's/.*<strong>//' $FreeServer2
	busybox sed -i 's|</h5>||' $FreeServer2
	busybox sed -i 's/<p><font color="red">//' $FreeServer2
	busybox sed -i 's/Copy Your Free cccam : <strong>//' $FreeServer2
	busybox sed -i 's|<center><strong>||' $FreeServer2
	busybox sed -i 's| <br><h6>.*||' $FreeServer2
	busybox sed -i 's|</font><br />||' $FreeServer2
	busybox sed -i 's|</h6></strong></center>||' $FreeServer2
	busybox sed -i 's/                                    <h4><p style="text-align: center;"><span class="id-color">//' $FreeServer2
	busybox sed -i 's|<center><div class="label label-success"><strong>||' $FreeServer2
	busybox sed -i 's|<a href="http://cccamstore.tv">www.cccamstore.tv</a></li>||' $FreeServer2
	busybox sed -i 's/								<center><h1><div class="label label-success"><strong>//' $FreeServer2
	busybox sed -i 's/<h1 class="wow fadeInDown" data-wow-delay="0.4s"> //' $FreeServer2
	busybox sed -i 's|</p> <!--edit here-->||' $FreeServer2
	busybox sed -i 's/<h4 style="background-color:MediumSeaGreen;"> //' $FreeServer2
	busybox sed -i 's/<center><h3><div class="panel panel-success" ><div class="panel-heading">Your Free Cline is <br><br>//' $FreeServer2
	busybox sed -i 's/<div class="panel-heading">Your Free Cline is <br><br>//' $FreeServer2
	busybox sed -i 's/			<h4 style="background-color:MediumSeaGreen;">   <center><strong>//' $FreeServer2
	busybox sed -i 's/<p class="text-center">Your Free Test line : <strong>//' $FreeServer2
	busybox sed -i 's/<p class="text-center//' $FreeServer2
	busybox sed -i 's|</strong></p>||' $FreeServer2
	busybox sed -i 's#.*Cline</th><th class="tg-juwk">##' $FreeServer2
	busybox sed -i 's#</th></tr><tr><td.*##' $FreeServer2
	busybox sed -i 's/<p class="text-center">Your Free Test line : <strong>//' $FreeServer2
	busybox sed -i 's|<h4 style="background-color:MediumSeaGreen;">   <center><strong>||' $FreeServer2
	busybox sed -i 's/<h4><p style="text-align: center;"><span class="id-color">//' $FreeServer2
	busybox sed -i 's/<h2><p style="text-align: center;"><span class="id-color">//' $FreeServer2
	busybox sed -i 's/<center><p style="text-align: center;" color="green"> <b class="c-pink"> //' $FreeServer2
	busybox sed -i 's|</b></p></center>||' $FreeServer2
	busybox sed -i 's/<p>//' $FreeServer2
	busybox sed -i 's|</p>||' $FreeServer2
	busybox sed -i 's|</p></span></h4>||' $FreeServer2
	busybox sed -i 's|<p style="text-align: center;"><strong>||' $FreeServer2
	busybox sed -i 's|">||' $FreeServer2
	busybox sed -i 's/">//' $FreeServer2  
	busybox sed -i 's/port: //' $FreeServer2
	busybox sed -i 's/user: //' $FreeServer2
	busybox sed -i 's/pass: //' $FreeServer2
	busybox sed -i 's/<input type="hidden" name="Username" value="//' $FreeServer2
	busybox sed -i 's/<input type="hidden" name="Password" value="// ' $FreeServer2
	busybox sed -i 's|<span class="generalBorder</span>||' $FreeServer2
	busybox sed -i 's/.*<font size="8"><FONT COLOR="#00FF0D">//' $FreeServer2
	busybox sed -i 's/<font color="blue//' $FreeServer2 
	busybox sed -i 's|</p></h4>||' $FreeServer2  
	busybox sed -i 's|</span>||' $FreeServer2
	busybox sed -i 's|<span class="text-blue||' $FreeServer2
	busybox sed -i 's|</span>||' $FreeServer2
	busybox sed -i 's/<h2> //' $FreeServer2
	busybox sed -i 's|</h2>||' $FreeServer2
	busybox sed -i 's/<h2><p style="text-align: center;"><span class="id-color">//' $FreeServer2
	busybox sed -i 's|\n||' $FreeServer2
	busybox sed -i 's|\t||' $FreeServer2
	busybox sed -i 's|\r||' $FreeServer2
	busybox sed -i 's|  ||' $FreeServer2
	busybox sed -i '/^$/d' $FreeServer2
	busybox sed -i 's|<br||' $FreeServer2
	busybox sed -i 's| />||' $FreeServer2
	grep -i "C:.*" $FreeServer2 > conv2.tmp
	grep -i "c:.*" conv2.tmp > conv.tmp

	echo $cur $fin $total

	FS=" "

	cat $FreeServer2 | cut -d'C' -f 2 > conv.tmp

	while read F1 SERVER PORT USER PASS; do
		echo "[reader]"						>> $OUTPUT2
		echo "label = $SERVER"				>> $OUTPUT2
		echo "protocol = cccam"				>> $OUTPUT2
		echo "device = $SERVER,$PORT"		>> $OUTPUT2
		echo "user = $USER"					>> $OUTPUT2
		echo "password = $PASS"				>> $OUTPUT2
		echo "group = 1"					>> $OUTPUT2
		echo "cccversion = 2.2.1"			>> $OUTPUT2
		echo ""								>> $OUTPUT2
	done < conv.tmp

	(( fin = fin + 1 ))

	echo $cur $fin $total
#NCam Path
	cat $FreeServer2 | cut -d'C' -f 2 > conv.tmp

	while read F1 SERVER PORT USER PASS; do
		echo "[reader]"						>> $OUTPUT3
		echo "label = $SERVER"				>> $OUTPUT3
		echo "protocol = cccam"				>> $OUTPUT3
		echo "device = $SERVER,$PORT"		>> $OUTPUT3
		echo "user = $USER"					>> $OUTPUT3
		echo "password = $PASS"				>> $OUTPUT3
		echo "group = 1"					>> $OUTPUT3
		echo "cccversion = 2.2.1"			>> $OUTPUT3
		echo ""								>> $OUTPUT3
	done < conv.tmp

	#(( fin = fin + 1 ))

	echo $cur $fin $total
#NCamx Path
	cat $FreeServer2 | cut -d'C' -f 2 > conv.tmp

	while read F1 SERVER PORT USER PASS; do
		echo "[reader]"						>> $OUTPUT4
		echo "label = $SERVER"				>> $OUTPUT4
		echo "protocol = cccam"				>> $OUTPUT4
		echo "device = $SERVER,$PORT"		>> $OUTPUT4
		echo "user = $USER"					>> $OUTPUT4
		echo "password = $PASS"				>> $OUTPUT4
		echo "group = 1"					>> $OUTPUT4
		echo "cccversion = 2.2.1"			>> $OUTPUT4
		echo ""								>> $OUTPUT4
	done < conv.tmp

	#(( fin = fin + 1 ))

	echo $cur $fin $total
	
	rm conv.tmp > /dev/null 2>&1
	rm conv2.tmp > /dev/null 2>&1
	rm FreeServer.txt > /dev/null 2>&1
	rm server.txt > /dev/null 2>&1
done

#cat oscam.server